from pages.main import Main

if __name__ == "__main__":
    app = Main()
    app.mainloop()