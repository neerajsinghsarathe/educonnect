import tkinter as tk


class Quizzes:
    def __init__(self, root):
        pass
