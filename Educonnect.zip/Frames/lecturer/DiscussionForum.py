import tkinter as tk


class DiscussionForum:
    def __init__(self, root):
        pass
