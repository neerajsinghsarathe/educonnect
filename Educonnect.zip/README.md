# EduConnect

EduConnect is a platform to connect students with Professors and Lecturers. This application helps to share materials conduct quizzes and assignments and interact with 
other students and lecturers. 


# Tech Stack

1. [Python]() 
2. [Tkinter]()
3. [Socket Programming]()